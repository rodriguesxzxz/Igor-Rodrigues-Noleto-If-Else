package ex9;
import java.util.Scanner;
public class Ex9 {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
double salario, desconto;
System.out.print("Digite o salário: ");
salario = sc.nextDouble();
if (salario <= 600) {
desconto = 0;
} else if (salario <= 1200) {
desconto = salario * 0.20;
} else if (salario <= 2000) {
desconto = salario * 0.25;
} else {
desconto = salario * 0.30;
}
System.out.println("Desconto do INSS: R$ " + desconto);
}
}