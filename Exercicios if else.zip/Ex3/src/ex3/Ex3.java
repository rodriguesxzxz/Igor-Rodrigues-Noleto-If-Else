package ex3;
import java.util.Scanner;
public class Ex3 {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
double altura, pesoIdeal;
char sexo;
System.out.print("Digite a altura: ");
altura = sc.nextDouble();
System.out.print("Digite o sexo (M/F): ");
sexo = sc.next().charAt(0);

if (sexo == 'M' || sexo == 'm') {
pesoIdeal = (72.7 * altura) - 58;
} else {
pesoIdeal = (62.1 * altura) - 44.7;
}
 System.out.println("Peso ideal: " + pesoIdeal);
    }
}