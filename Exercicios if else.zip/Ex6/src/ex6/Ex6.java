package ex6;
import java.util.Scanner;
public class Ex6 {
public static void main(String[] args) {
 Scanner sc = new Scanner(System.in);
double salario, prestacao;
System.out.print("Digite o salário bruto: ");
salario = sc.nextDouble();
System.out.print("Digite o valor da prestação: ");
prestacao = sc.nextDouble();
if (prestacao <= salario * 0.30) {
System.out.println("Empréstimo pode ser concedido!");
} else {
 System.out.println("Empréstimo não pode ser concedido!");
}
}
}
   