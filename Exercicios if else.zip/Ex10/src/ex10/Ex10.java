package ex10;
import java.util.Scanner;
public class Ex10 {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
double n1, n2, resultado;
char op;
System.out.print("Digite o primeiro número: ");
n1 = sc.nextDouble();
System.out.print("Digite o segundo número: ");
n2 = sc.nextDouble();
System.out.print("Digite a operação (+, -, *, /): ");
op = sc.next().charAt(0);
switch (op) {
case '+' -> {
    resultado = n1 + n2;
    System.out.println("Resultado: " + resultado);
        }
case '-' -> {
    resultado = n1 - n2;
    System.out.println("Resultado: " + resultado);
        }
case '*' -> {
    resultado = n1 * n2;
    System.out.println("Resultado: " + resultado);
        }
case '/' -> {
    if (n2 <= 0) {
        System.out.println("Impossível dividir!");
    } else {
        resultado = n1 / n2;
        System.out.println("Resultado: " + resultado);
    }       }
default -> System.out.println("Sinal inválido");
}
}
}
