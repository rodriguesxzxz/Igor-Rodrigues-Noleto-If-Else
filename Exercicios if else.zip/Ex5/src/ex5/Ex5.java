package ex5;
import java.util.Scanner;
public class Ex5 {
 public static void main(String[] args) {
 Scanner sc = new Scanner(System.in);
String senha;
System.out.print("Digite a senha: ");
senha = sc.nextLine();
if (senha.equals("R10p5")) {
System.out.println("Acesso concedido");
 } else {
System.out.println("Acesso negado");
        }
    }
}
