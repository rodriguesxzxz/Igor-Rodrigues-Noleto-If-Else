package ex4;
import java.util.Scanner;
public class Ex4 {
 public static void main(String[] args) {
 Scanner sc = new Scanner(System.in);

double salario, bonus;
int anos;

System.out.print("Digite o salário: ");
salario = sc.nextDouble();

System.out.print("Digite anos de trabalho: ");
anos = sc.nextInt();

if (anos >= 5) {
bonus = salario * 0.20;
} else {
bonus = salario * 0.10;
}
System.out.println("Bônus: " + bonus);
    }
}