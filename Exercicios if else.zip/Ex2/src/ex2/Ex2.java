package ex2;
import java.util.Scanner;
public class Ex2 {
    public static void main(String[] args) {
 Scanner sc = new Scanner(System.in);

int num;

System.out.print("Digite um número: ");
num = sc.nextInt();
 if (num >= 50 && num <= 100) {
 System.out.println("Pertence ao intervalo");
 } else {
 System.out.println("Não pertence ao intervalo");
}
}
}