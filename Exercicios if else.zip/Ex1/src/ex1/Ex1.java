package ex1;
import java.util.Scanner;

public class Ex1 {

    public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
  
  float n1, n2;System.out.print("Digite o primeiro número: ");
  /**

* float é um tipo de dado usado para armazenar números com casas decimais.
*/
  n1 = sc.nextFloat();

System.out.print("Digite o segundo número: ");
 n2 = sc.nextFloat();

if (n1 > n2) {
 System.out.println("Ordem decrescente: " + n1 + " - " + n2);
} else {
System.out.println("Ordem decrescente: " + n2 + " - " + n1);
}
}
}